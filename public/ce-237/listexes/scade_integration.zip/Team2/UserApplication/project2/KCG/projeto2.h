/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/scade-integration-example-1/Team2/UserApplication/project2/KCG/config.txt
** Generation date: 2020-10-28T20:28:01
*************************************************************$ */
#ifndef _projeto2_H_
#define _projeto2_H_

#include "kcg_types.h"

/* ========================  input structure  ====================== */
typedef struct {
  kcg_bool /* SignalFromButton/, _L4/ */ SignalFromButton;
  kcg_bool /* @1/Input/, @1/_L4/, SignalFromTeam1/, _L5/ */ SignalFromTeam1;
} inC_projeto2;

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* ReqLayerVisible/ */ ReqLayerVisible;
  kcg_bool /* ReqLayerActive/, _L3/ */ ReqLayerActive;
  kcg_bool /* SignalToTeam1/ */ SignalToTeam1;
  kcg_uint8 /* SignalToLED/, _L7/ */ SignalToLED;
  kcg_bool /* EmitToCDS/, _L10/ */ EmitToCDS;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool /* @1/_L1/ */ _L1_Toggle_1;
  kcg_bool /* _L1/ */ _L1;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
} outC_projeto2;

/* ===========  node initialization and cycle functions  =========== */
/* projeto2/ */
extern void projeto2(inC_projeto2 *inC, outC_projeto2 *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void projeto2_reset(outC_projeto2 *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void projeto2_init(outC_projeto2 *outC);
#endif /* KCG_USER_DEFINED_INIT */

/*
  Expanded instances for: projeto2/
  @1: (Toggle#1)
*/

#endif /* _projeto2_H_ */
/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** projeto2.h
** Generation date: 2020-10-28T20:28:01
*************************************************************$ */

