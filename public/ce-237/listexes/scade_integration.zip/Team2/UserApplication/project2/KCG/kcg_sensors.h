/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/scade-integration-example-1/Team2/UserApplication/project2/KCG/config.txt
** Generation date: 2020-10-28T20:28:01
*************************************************************$ */
#ifndef _KCG_SENSORS_H_
#define _KCG_SENSORS_H_

#include "kcg_types.h"

#endif /* _KCG_SENSORS_H_ */
/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** kcg_sensors.h
** Generation date: 2020-10-28T20:28:01
*************************************************************$ */

