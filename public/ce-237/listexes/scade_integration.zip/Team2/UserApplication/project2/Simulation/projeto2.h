/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/scade-integration-example-1/Team2/UserApplication/project2/Simulation/config.txt
** Generation date: 2020-10-28T20:38:01
*************************************************************$ */
#ifndef _projeto2_H_
#define _projeto2_H_

#include "kcg_types.h"

/* ========================  input structure  ====================== */
typedef struct {
  kcg_bool /* SignalFromButton/ */ SignalFromButton;
  kcg_bool /* SignalFromTeam1/ */ SignalFromTeam1;
} inC_projeto2;

/* ========================  output structure  ====================== */
typedef struct {
  kcg_bool * /* ReqLayerVisible/ */ ReqLayerVisible;
  kcg_bool * /* ReqLayerActive/ */ ReqLayerActive;
  kcg_bool * /* SignalToTeam1/ */ SignalToTeam1;
  kcg_uint8 * /* SignalToLED/ */ SignalToLED;
  kcg_bool * /* EmitToCDS/ */ EmitToCDS;
} outS_projeto2;

/* ========================  context type  ========================= */
typedef struct {
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool init;
  kcg_bool /* @1/_L1/ */ _L1_Toggle_1;
  kcg_bool /* _L1/ */ _L1;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
  /* -------------------- (-debug) no assertions  -------------------- */
  /* ------------------- (-debug) local variables -------------------- */
  kcg_bool /* @1/Output/ */ Output_Toggle_1;
  kcg_bool /* @1/Input/ */ Input_Toggle_1;
  kcg_bool /* @1/_L2/ */ _L2_Toggle_1;
  kcg_bool /* @1/_L3/ */ _L3_Toggle_1;
  kcg_bool /* @1/_L4/ */ _L4_Toggle_1;
  kcg_bool /* _L3/ */ _L3;
  kcg_bool /* _L4/ */ _L4;
  kcg_bool /* _L5/ */ _L5;
  kcg_bool /* _L6/ */ _L6;
  kcg_uint8 /* _L7/ */ _L7;
  kcg_uint8 /* _L8/ */ _L8;
  kcg_uint8 /* _L9/ */ _L9;
  kcg_bool /* _L10/ */ _L10;
} outC_projeto2;

/* ===========  node initialization and cycle functions  =========== */
/* projeto2/ */
extern void projeto2(
  inC_projeto2 *inC,
  outS_projeto2 *outS,
  outC_projeto2 *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void projeto2_reset(outC_projeto2 *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void projeto2_init(outC_projeto2 *outC);
#endif /* KCG_USER_DEFINED_INIT */

/*
  Expanded instances for: projeto2/
  @1: (Toggle#1)
*/

#endif /* _projeto2_H_ */
/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** projeto2.h
** Generation date: 2020-10-28T20:38:01
*************************************************************$ */

