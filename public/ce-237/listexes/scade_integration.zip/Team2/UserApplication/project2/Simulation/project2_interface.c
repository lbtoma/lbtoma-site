#include "project2_interface.h"
#include "project2_type.h"
#include "project2_mapping.h"
#include "SmuVTable.h"
#include <string.h>

#define UNUSED(x) (void)(x)
/* context */

inC_projeto2 inputs_ctx;
static inC_projeto2 inputs_ctx_execute;
kcg_bool ReqLayerVisible;
kcg_bool ReqLayerActive;
kcg_bool SignalToTeam1;
kcg_uint8 SignalToLED;
kcg_bool EmitToCDS;
outS_projeto2 outputs_str;
outC_projeto2 outputs_ctx;

static void _SCSIM_RestoreInterface(void) {
    init_kcg_bool(&inputs_ctx.SignalFromButton);
    init_kcg_bool(&inputs_ctx_execute.SignalFromButton);
    init_kcg_bool(&inputs_ctx.SignalFromTeam1);
    init_kcg_bool(&inputs_ctx_execute.SignalFromTeam1);
    init_kcg_bool(&ReqLayerVisible);
    outputs_str.ReqLayerVisible = &ReqLayerVisible;
    init_kcg_bool(&ReqLayerActive);
    outputs_str.ReqLayerActive = &ReqLayerActive;
    init_kcg_bool(&SignalToTeam1);
    outputs_str.SignalToTeam1 = &SignalToTeam1;
    init_kcg_uint8(&SignalToLED);
    outputs_str.SignalToLED = &SignalToLED;
    init_kcg_bool(&EmitToCDS);
    outputs_str.EmitToCDS = &EmitToCDS;
    memset((void*)&outputs_ctx, 0, sizeof(outputs_ctx));
}

static void _SCSIM_ExecuteInterface(void) {
    pSimulator->m_pfnAcquireValueMutex(pSimulator);
    inputs_ctx_execute.SignalFromButton = inputs_ctx.SignalFromButton;
    inputs_ctx_execute.SignalFromTeam1 = inputs_ctx.SignalFromTeam1;
    pSimulator->m_pfnReleaseValueMutex(pSimulator);
}

#ifdef __cplusplus
extern "C" {
#endif

const int  rt_version = Srtv62;

const char* _SCSIM_CheckSum = "295edbd1a0f40a955c2bcdae7383e636";
const char* _SCSIM_SmuTypesCheckSum = "6757860ac1d8ce9bd3fc91d925ceefb8";

/* simulation */

int SimInit(void) {
    int nRet = 0;
    _SCSIM_RestoreInterface();
#ifdef EXTENDED_SIM
    BeforeSimInit();
#endif
#ifndef KCG_USER_DEFINED_INIT
    projeto2_init(&outputs_ctx);
    nRet = 1;
#else
    nRet = 0;
#endif
#ifdef EXTENDED_SIM
    AfterSimInit();
#endif
    return nRet;
}

int SimReset(void) {
    int nRet = 0;
    _SCSIM_RestoreInterface();
#ifdef EXTENDED_SIM
    BeforeSimInit();
#endif
#ifndef KCG_NO_EXTERN_CALL_TO_RESET
    projeto2_reset(&outputs_ctx);
    nRet = 1;
#else
    nRet = 0;
#endif
#ifdef EXTENDED_SIM
    AfterSimInit();
#endif
    return nRet;
}

#ifdef __cplusplus
    #ifdef pSimoutC_projeto2CIVTable_defined
        extern struct SimCustomInitVTable *pSimoutC_projeto2CIVTable;
    #else 
        struct SimCustomInitVTable *pSimoutC_projeto2CIVTable = NULL;
    #endif
#else
    struct SimCustomInitVTable *pSimoutC_projeto2CIVTable;
#endif

int SimCustomInit(void) {
    int nRet = 0;
    if (pSimoutC_projeto2CIVTable != NULL && 
        pSimoutC_projeto2CIVTable->m_pfnCustomInit != NULL) {
        /* VTable function provided => call it */
        nRet = pSimoutC_projeto2CIVTable->m_pfnCustomInit ((void*)&outputs_ctx);
    }
    else {
        /* VTable misssing => error */
        nRet = 0;
    }
    return nRet;
}

#ifdef EXTENDED_SIM
    int GraphicalInputsConnected = 1;
#endif

int SimStep(void) {
#ifdef EXTENDED_SIM
    if (GraphicalInputsConnected)
        BeforeSimStep();
#endif
    _SCSIM_ExecuteInterface();
    projeto2(&inputs_ctx_execute, &outputs_str, &outputs_ctx);
#ifdef EXTENDED_SIM
    AfterSimStep();
#endif
    return 1;
}

int SimStop(void) {
#ifdef EXTENDED_SIM
    ExtendedSimStop();
#endif
    return 1;
}

void SsmUpdateValues(void) {
#ifdef EXTENDED_SIM
    UpdateValues();
#endif
}

void SsmConnectExternalInputs(int bConnect) {
#ifdef EXTENDED_SIM
    GraphicalInputsConnected = bConnect;
#else
    UNUSED(bConnect);
#endif
}

/* dump */

int SsmGetDumpSize(void) {
    int nSize = 0;
    nSize += sizeof(inC_projeto2);
    nSize += sizeof(kcg_bool);
    nSize += sizeof(kcg_bool);
    nSize += sizeof(kcg_bool);
    nSize += sizeof(kcg_uint8);
    nSize += sizeof(kcg_bool);
    nSize += sizeof(outC_projeto2);
#ifdef EXTENDED_SIM
    nSize += ExtendedGetDumpSize();
#endif
    return nSize;
}

void SsmGatherDumpData(char * pData) {
    char* pCurrent = pData;
    memcpy(pCurrent, &inputs_ctx, sizeof(inC_projeto2));
    pCurrent += sizeof(inC_projeto2);
    memcpy(pCurrent, &ReqLayerVisible, sizeof(kcg_bool));
    pCurrent += sizeof(kcg_bool);
    memcpy(pCurrent, &ReqLayerActive, sizeof(kcg_bool));
    pCurrent += sizeof(kcg_bool);
    memcpy(pCurrent, &SignalToTeam1, sizeof(kcg_bool));
    pCurrent += sizeof(kcg_bool);
    memcpy(pCurrent, &SignalToLED, sizeof(kcg_uint8));
    pCurrent += sizeof(kcg_uint8);
    memcpy(pCurrent, &EmitToCDS, sizeof(kcg_bool));
    pCurrent += sizeof(kcg_bool);
    memcpy(pCurrent, &outputs_ctx, sizeof(outC_projeto2));
    pCurrent += sizeof(outC_projeto2);
#ifdef EXTENDED_SIM
    ExtendedGatherDumpData(pCurrent);
#endif
}

void SsmRestoreDumpData(const char * pData) {
    const char* pCurrent = pData;
    memcpy(&inputs_ctx, pCurrent, sizeof(inC_projeto2));
    pCurrent += sizeof(inC_projeto2);
    memcpy(&outputs_ctx, pCurrent, sizeof(outC_projeto2));
    pCurrent += sizeof(outC_projeto2);
#ifdef EXTENDED_SIM
    ExtendedRestoreDumpData(pCurrent);
#endif
}

/* snapshot */

int SsmSaveSnapshot(const char * szFilePath, size_t nCycle) {
    /* Test Services API not available */
    UNUSED(szFilePath);
    UNUSED(nCycle);
    return 0;
}

int SsmLoadSnapshot(const char * szFilePath, size_t *nCycle) {
    /* Test Services API not available */
    UNUSED(szFilePath);
    UNUSED(nCycle);
    return 0;
}

/* checksum */

const char * SsmGetCheckSum() {
    return _SCSIM_CheckSum;
}

const char * SsmGetSmuTypesCheckSum() {
    return _SCSIM_SmuTypesCheckSum;
}

#ifdef __cplusplus
} /* "C" */
#endif

