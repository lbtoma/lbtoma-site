#include "ua.h"
#include "projeto2.h"

typedef inC_projeto2 operator_input_type;
typedef outC_projeto2 operator_output_type;
