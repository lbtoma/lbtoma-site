#include "ua.h"
#include "projeto1.h"

typedef inC_projeto1 operator_input_type;
typedef outC_projeto1 operator_output_type;
