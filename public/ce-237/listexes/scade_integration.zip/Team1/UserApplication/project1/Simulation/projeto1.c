/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/scade-integration-example-1/Team1/UserApplication/project1/Simulation/config.txt
** Generation date: 2020-10-28T19:42:45
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "projeto1.h"

/* projeto1/ */
void projeto1(inC_projeto1 *inC, outS_projeto1 *outS, outC_projeto1 *outC)
{
  outC->_L5 = inC->SignalFromTeam2;
  outC->Input_Toggle_1 = outC->_L5;
  outC->_L4_Toggle_1 = outC->Input_Toggle_1;
  /* @1/_L2= */
  if (outC->init) {
    outC->_L2_Toggle_1 = kcg_false;
  }
  else {
    outC->_L2_Toggle_1 = outC->_L1_Toggle_1;
  }
  outC->_L3_Toggle_1 = !outC->_L2_Toggle_1;
  /* @1/_L1= */
  if (outC->_L4_Toggle_1) {
    outC->_L1_Toggle_1 = outC->_L3_Toggle_1;
  }
  else {
    outC->_L1_Toggle_1 = outC->_L2_Toggle_1;
  }
  outC->Output_Toggle_1 = outC->_L1_Toggle_1;
  outC->_L10 = kcg_true;
  *outS->EmitToCDS = outC->_L10;
  outC->_L9 = RED;
  outC->_L8 = GREEN;
  outC->_L6 = outC->Output_Toggle_1;
  /* _L7= */
  if (outC->_L6) {
    outC->_L7 = outC->_L8;
  }
  else {
    outC->_L7 = outC->_L9;
  }
  *outS->SignalToLED = outC->_L7;
  outC->_L4 = inC->SignalFromButton;
  *outS->SignalToTeam2 = outC->_L4;
  /* _L3= */
  if (outC->init) {
    outC->_L3 = kcg_true;
  }
  else {
    outC->_L3 = outC->_L1;
  }
  *outS->ReqLayerActive = outC->_L3;
  *outS->ReqLayerVisible = outC->_L3;
  outC->_L1 = kcg_false;
  outC->init = kcg_false;
}

#ifndef KCG_USER_DEFINED_INIT
void projeto1_init(outC_projeto1 *outC)
{
  outC->_L10 = kcg_true;
  outC->_L9 = kcg_lit_uint8(0);
  outC->_L8 = kcg_lit_uint8(0);
  outC->_L7 = kcg_lit_uint8(0);
  outC->_L6 = kcg_true;
  outC->_L5 = kcg_true;
  outC->_L4 = kcg_true;
  outC->_L3 = kcg_true;
  outC->_L4_Toggle_1 = kcg_true;
  outC->_L3_Toggle_1 = kcg_true;
  outC->_L2_Toggle_1 = kcg_true;
  outC->Input_Toggle_1 = kcg_true;
  outC->Output_Toggle_1 = kcg_true;
  outC->_L1 = kcg_true;
  outC->_L1_Toggle_1 = kcg_true;
  outC->init = kcg_true;
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void projeto1_reset(outC_projeto1 *outC)
{
  outC->init = kcg_true;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

/*
  Expanded instances for: projeto1/
  @1: (Toggle#1)
*/

/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** projeto1.c
** Generation date: 2020-10-28T19:42:45
*************************************************************$ */

