/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/scade-integration-example-1/Team1/UserApplication/project1/Simulation/config.txt
** Generation date: 2020-10-28T19:42:45
*************************************************************$ */

#include "kcg_consts.h"

/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** kcg_consts.c
** Generation date: 2020-10-28T19:42:45
*************************************************************$ */

