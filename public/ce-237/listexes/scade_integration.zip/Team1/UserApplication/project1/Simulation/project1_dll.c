const char*  pszDllPathname = "projeto1.dll";
const char*  pszLauncherPathname = "C:/Program Files/ANSYS Inc/v202/SCADE/SCADE/bin/SCSSMLNC.exe";
