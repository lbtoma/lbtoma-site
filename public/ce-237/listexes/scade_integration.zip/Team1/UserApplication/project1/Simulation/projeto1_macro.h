#ifndef _PROJETO1_MACRO_H_
#define _PROJETO1_MACRO_H_


/*$************** SCADE Macro wrapper *********************
** Begin of file projeto1_macro.h
***********************************************************$*/


/*$**********************************************************
*                        INCLUDES
***********************************************************$*/

/* includes */
#include "projeto1.h"

/*$**********************************************************
*                           CONTEXT
***********************************************************$*/

typedef struct {
    inC_projeto1 inputs_ctx;
    kcg_bool ReqLayerVisible; /* output 0 */
    kcg_bool ReqLayerActive; /* output 1 */
    kcg_bool SignalToTeam2; /* output 2 */
    kcg_uint8 SignalToLED; /* output 3 */
    kcg_bool EmitToCDS; /* output 4 */
    outS_projeto1 outputs_str;
    outC_projeto1 outputs_ctx;
} WU_projeto1;
#define WU_CTX_TYPE_projeto1 WU_projeto1
#define WU_CTX_TYPE_projeto1_SIZE sizeof(WU_projeto1)

/*$**********************************************************
*                           SENSORS
***********************************************************$*/

#define DECLARE_SENSORS_projeto1() 

#define DECLARE_EXT_SENSORS_projeto1(MODE) 

/*$**********************************************************
*                           INPUTS
***********************************************************$*/

#define VARC_projeto1_SignalFromButton(context) context.inputs_ctx.SignalFromButton  /* projeto1/SignalFromButton */
#define VAR_projeto1_SignalFromButton VARC_projeto1_SignalFromButton(CTX_projeto1)

#define VARC_projeto1_SignalFromTeam2(context) context.inputs_ctx.SignalFromTeam2  /* projeto1/SignalFromTeam2 */
#define VAR_projeto1_SignalFromTeam2 VARC_projeto1_SignalFromTeam2(CTX_projeto1)


/*$**********************************************************
*                           OUTPUTS
***********************************************************$*/

#define VARC_projeto1_ReqLayerVisible(context) context.outputs_ctx.ReqLayerVisible  /* projeto1/ReqLayerVisible */
#define VAR_projeto1_ReqLayerVisible VARC_projeto1_ReqLayerVisible(CTX_projeto1)

#define VARC_projeto1_ReqLayerActive(context) context.outputs_ctx.ReqLayerActive  /* projeto1/ReqLayerActive */
#define VAR_projeto1_ReqLayerActive VARC_projeto1_ReqLayerActive(CTX_projeto1)

#define VARC_projeto1_SignalToTeam2(context) context.outputs_ctx.SignalToTeam2  /* projeto1/SignalToTeam2 */
#define VAR_projeto1_SignalToTeam2 VARC_projeto1_SignalToTeam2(CTX_projeto1)

#define VARC_projeto1_SignalToLED(context) context.outputs_ctx.SignalToLED  /* projeto1/SignalToLED */
#define VAR_projeto1_SignalToLED VARC_projeto1_SignalToLED(CTX_projeto1)

#define VARC_projeto1_EmitToCDS(context) context.outputs_ctx.EmitToCDS  /* projeto1/EmitToCDS */
#define VAR_projeto1_EmitToCDS VARC_projeto1_EmitToCDS(CTX_projeto1)


/*$**********************************************************
*                           ELEMENT ACCESS
***********************************************************$*/

#define GET_ELEMENT_AT(VARIABLE, INDEX)  (VARIABLE)[INDEX]
#define GET_STRUCTURE_FIELD(VARIABLE, FIELD) (VARIABLE).FIELD

/*$**********************************************************
*                        VARIABLES TYPES
***********************************************************$*/

#define T_SignalFromButton kcg_bool
#define CPY_SignalFromButton(DST, SRC) DST = SRC
#define T_SignalFromTeam2 kcg_bool
#define CPY_SignalFromTeam2(DST, SRC) DST = SRC
#define T_ReqLayerVisible kcg_bool
#define CPY_ReqLayerVisible(DST, SRC) DST = SRC
#define T_ReqLayerActive kcg_bool
#define CPY_ReqLayerActive(DST, SRC) DST = SRC
#define T_SignalToTeam2 kcg_bool
#define CPY_SignalToTeam2(DST, SRC) DST = SRC
#define T_SignalToLED kcg_uint8
#define CPY_SignalToLED(DST, SRC) DST = SRC
#define T_EmitToCDS kcg_bool
#define CPY_EmitToCDS(DST, SRC) DST = SRC


/*$**********************************************************
*                      CREATION, INIT AND PERFORM
***********************************************************$*/

#define DECLAREC_CTXT_projeto1(context)  WU_projeto1 context;

#define DECLARE_CTXT_projeto1() DECLAREC_CTXT_projeto1(CTX_projeto1)

#define DECLAREC_EXT_CTXT_projeto1(MODE , context) MODE WU_projeto1 context;

#define DECLARE_EXT_CTXT_projeto1(MODE) DECLAREC_EXT_CTXT_projeto1(MODE , CTX_projeto1)

#ifndef KCG_USER_DEFINED_INIT
#   define INITC_projeto1(context) projeto1_init(&context.outputs_ctx);
#else
#   ifndef KCG_NO_EXTERN_CALL_TO_RESET
#       define INITC_projeto1(context) projeto1_reset(&context.outputs_ctx);
#   else
#       define INITC_projeto1(context) 
#   endif
#endif
#define INIT_projeto1() INITC_projeto1(CTX_projeto1)

#define PERFORMC_projeto1(context) context.outputs_str.ReqLayerVisible = &context.ReqLayerVisible;\
context.outputs_str.ReqLayerActive = &context.ReqLayerActive;\
context.outputs_str.SignalToTeam2 = &context.SignalToTeam2;\
context.outputs_str.SignalToLED = &context.SignalToLED;\
context.outputs_str.EmitToCDS = &context.EmitToCDS;\
projeto1( \
    &context.inputs_ctx /* input context */,\
    &context.outputs_str /* output structure*/,\
    &context.outputs_ctx /* output/memories context */\
)
#define PERFORM_projeto1() PERFORMC_projeto1(CTX_projeto1)

/*$************** SCADE Macro wrapper *********************
** End of file projeto1_macro.h
***********************************************************$*/

#endif /* _PROJETO1_MACRO_H_ */
