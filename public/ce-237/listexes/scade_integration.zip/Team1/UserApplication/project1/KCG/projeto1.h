/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/scade-integration-example-1/Team1/UserApplication/project1/KCG/config.txt
** Generation date: 2020-10-28T19:42:07
*************************************************************$ */
#ifndef _projeto1_H_
#define _projeto1_H_

#include "kcg_types.h"

/* ========================  input structure  ====================== */
typedef struct {
  kcg_bool /* SignalFromButton/, _L4/ */ SignalFromButton;
  kcg_bool /* @1/Input/, @1/_L4/, SignalFromTeam2/, _L5/ */ SignalFromTeam2;
} inC_projeto1;

/* =====================  no output structure  ====================== */

/* ========================  context type  ========================= */
typedef struct {
  /* ---------------------------  outputs  --------------------------- */
  kcg_bool /* ReqLayerVisible/ */ ReqLayerVisible;
  kcg_bool /* ReqLayerActive/, _L3/ */ ReqLayerActive;
  kcg_bool /* SignalToTeam2/ */ SignalToTeam2;
  kcg_uint8 /* SignalToLED/, _L7/ */ SignalToLED;
  kcg_bool /* EmitToCDS/, _L10/ */ EmitToCDS;
  /* -----------------------  no local probes  ----------------------- */
  /* ----------------------- local memories  ------------------------- */
  kcg_bool /* @1/_L1/ */ _L1_Toggle_1;
  kcg_bool /* _L1/ */ _L1;
  /* -------------------- no sub nodes' contexts  -------------------- */
  /* ----------------- no clocks of observable data ------------------ */
} outC_projeto1;

/* ===========  node initialization and cycle functions  =========== */
/* projeto1/ */
extern void projeto1(inC_projeto1 *inC, outC_projeto1 *outC);

#ifndef KCG_NO_EXTERN_CALL_TO_RESET
extern void projeto1_reset(outC_projeto1 *outC);
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

#ifndef KCG_USER_DEFINED_INIT
extern void projeto1_init(outC_projeto1 *outC);
#endif /* KCG_USER_DEFINED_INIT */

/*
  Expanded instances for: projeto1/
  @1: (Toggle#1)
*/

#endif /* _projeto1_H_ */
/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** projeto1.h
** Generation date: 2020-10-28T19:42:07
*************************************************************$ */

