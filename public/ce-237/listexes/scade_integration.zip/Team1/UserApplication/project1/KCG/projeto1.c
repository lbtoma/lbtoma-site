/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/scade-integration-example-1/Team1/UserApplication/project1/KCG/config.txt
** Generation date: 2020-10-28T19:42:07
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "projeto1.h"

/* projeto1/ */
void projeto1(inC_projeto1 *inC, outC_projeto1 *outC)
{
  outC->EmitToCDS = kcg_true;
  /* @1/_L1= */
  if (inC->SignalFromTeam2) {
    outC->_L1_Toggle_1 = !outC->_L1_Toggle_1;
  }
  /* _L7= */
  if (outC->_L1_Toggle_1) {
    outC->SignalToLED = GREEN;
  }
  else {
    outC->SignalToLED = RED;
  }
  outC->ReqLayerActive = outC->_L1;
  outC->ReqLayerVisible = outC->_L1;
  outC->_L1 = kcg_false;
  outC->SignalToTeam2 = inC->SignalFromButton;
}

#ifndef KCG_USER_DEFINED_INIT
void projeto1_init(outC_projeto1 *outC)
{
  outC->_L1_Toggle_1 = kcg_false;
  outC->_L1 = kcg_true;
  outC->ReqLayerVisible = kcg_true;
  outC->ReqLayerActive = kcg_true;
  outC->SignalToTeam2 = kcg_true;
  outC->EmitToCDS = kcg_true;
  outC->SignalToLED = kcg_lit_uint8(0);
}
#endif /* KCG_USER_DEFINED_INIT */


#ifndef KCG_NO_EXTERN_CALL_TO_RESET
void projeto1_reset(outC_projeto1 *outC)
{
  outC->_L1_Toggle_1 = kcg_false;
  outC->_L1 = kcg_true;
}
#endif /* KCG_NO_EXTERN_CALL_TO_RESET */

/*
  Expanded instances for: projeto1/
  @1: (Toggle#1)
*/

/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** projeto1.c
** Generation date: 2020-10-28T19:42:07
*************************************************************$ */

