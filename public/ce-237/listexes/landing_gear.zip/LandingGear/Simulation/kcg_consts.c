/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/landing_gear/LandingGear/Simulation/config.txt
** Generation date: 2020-10-18T01:06:52
*************************************************************$ */

#include "kcg_consts.h"

/* LG_BTN_EMPTY_TEXT/ */
const T_String LG_BTN_EMPTY_TEXT = { ' ', ' ', ' ', ' ', ' ' };

/* LG_BTN_FAIL_TEXT/ */
const T_String LG_BTN_FAIL_TEXT = { 'F', 'A', 'I', 'L', ' ' };

/* LG_BTN_NORM_TEXT/ */
const T_String LG_BTN_NORM_TEXT = { 'N', 'O', 'R', 'M', ' ' };

/* LG_UP_TEXT/ */
const T_String LG_UP_TEXT = { 'U', 'P', ' ', ' ', ' ' };

/* LG_DOWN_TEXT/ */
const T_String LG_DOWN_TEXT = { 'D', 'N', ' ', ' ', ' ' };

/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** kcg_consts.c
** Generation date: 2020-10-18T01:06:52
*************************************************************$ */

