/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/landing_gear/LandingGear/Simulation/config.txt
** Generation date: 2020-10-18T01:06:53
*************************************************************$ */
#ifndef _KCG_SENSORS_H_
#define _KCG_SENSORS_H_

#include "kcg_types.h"

#endif /* _KCG_SENSORS_H_ */
/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** kcg_sensors.h
** Generation date: 2020-10-18T01:06:53
*************************************************************$ */

