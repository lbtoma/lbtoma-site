const char*  pszDllPathname = "Main.dll";
const char*  pszLauncherPathname = "C:/Program Files/ANSYS Inc/v202/SCADE/SCADE/bin/SCSSMLNC.exe";
