/* FuelManagement_mapping.h */
