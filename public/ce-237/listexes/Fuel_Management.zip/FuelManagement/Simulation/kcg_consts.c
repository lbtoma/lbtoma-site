/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** Command: kcg661.exe -config C:/Users/v8/Fuel_Management/FuelManagement/Simulation/config.txt
** Generation date: 2020-10-20T19:47:08
*************************************************************$ */

#include "kcg_consts.h"

/* $******* SCADE Suite KCG 32-bit 6.6.1 beta (build i1) ********
** kcg_consts.c
** Generation date: 2020-10-20T19:47:08
*************************************************************$ */

